﻿namespace ChainOfResponsibility.DAL
{
    public class CustomerProcess
    {
        public int CustomerProcessID { get; set; }
        public string Name { get; set; }
        public string Amount { get; set; }
        public string EmployeeName { get; set; }
        public string Description { get; set; }
    }
}
