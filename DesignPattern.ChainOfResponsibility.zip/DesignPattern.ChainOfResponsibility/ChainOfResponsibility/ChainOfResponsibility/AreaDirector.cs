﻿using ChainOfResponsibility.DAL;
using ChainOfResponsibility.Models;

namespace ChainOfResponsibility.ChainOfResponsibility
{
    public class AreaDirector : Employee
    {
        public override void ProcessRequest(CustomerProcessViewModel req)
        {
            Context c = new Context();
            CustomerProcess process = new CustomerProcess();
            if (req.Amount < 400000)
            {
                process.Amount = req.Amount.ToString();
                process.Name = req.Name;
                process.EmployeeName = "Bölge Müdürü - Emre Hanoğlu";
                process.Description = "Para Çekme İşlemi Onaylandı, Müşteriye Talep Ettiği Tutar Ödendi.(Maks Tutar - 400000)";
                c.customerProcesses.Add(process);
                c.SaveChanges();
            }
            else
            {
                process.Amount = req.Amount.ToString();
                process.Name = req.Name;
                process.EmployeeName = "Bölge Müdürü - Emre Hanoğlu";
                process.Description = "Para Çekme İşlemi Günlük Limiti Aştı, Müşterinin günlük çekebileceği maksimum tutar 400000TL" +
                    "olup daha fazlası için birden fazla gün şubeye gelmesi gereklidir.";
                c.customerProcesses.Add(process);
                c.SaveChanges();
            }
        }
    }
}
