﻿using ChainOfResponsibility.DAL;
using ChainOfResponsibility.Models;

namespace ChainOfResponsibility.ChainOfResponsibility
{
    public class Treasurer : Employee
    {
        public override void ProcessRequest(CustomerProcessViewModel req)
        {
            Context c = new Context();
            CustomerProcess process = new CustomerProcess();
            if(req.Amount < 100000)
            {
                process.Amount = req.Amount.ToString();
                process.Name = req.Name;
                process.EmployeeName = "Veznedar - Onur Zeyrek";
                process.Description = "Para Çekme İşlemi Onaylandı, Müşteriye Talep Ettiği Tutar Ödendi.(Maks Tutar - 100000)";
                c.customerProcesses.Add(process);
                c.SaveChanges();
            }
            else if(NextApprover != null)
            {
                process.Amount = req.Amount.ToString();
                process.Name = req.Name;
                process.EmployeeName = "Veznedar - Onur Zeyrek";
                process.Description = "Para Çekme İşlemi Günlük Limiti Aştı, İşlem Müdür Yardımcısına Yönlendirildi.";
                c.customerProcesses.Add(process);
                c.SaveChanges();
                NextApprover.ProcessRequest(req);
            }            
        }
    }
}
