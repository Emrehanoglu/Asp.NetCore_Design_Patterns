﻿using ChainOfResponsibility.DAL;
using ChainOfResponsibility.Models;

namespace ChainOfResponsibility.ChainOfResponsibility
{
    public class ManagerAssistans : Employee
    {
        public override void ProcessRequest(CustomerProcessViewModel req)
        {
            Context c = new Context();
            CustomerProcess process = new CustomerProcess();
            if (req.Amount < 150000)
            {
                process.Amount = req.Amount.ToString();
                process.Name = req.Name;
                process.EmployeeName = "Şube Müdür Yardımcısı - Muammer Akal";
                process.Description = "Para Çekme İşlemi Onaylandı, Müşteriye Talep Ettiği Tutar Ödendi.(Maks Tutar - 150000)";
                c.customerProcesses.Add(process);
                c.SaveChanges();
            }
            else if (NextApprover != null)
            {
                process.Amount = req.Amount.ToString();
                process.Name = req.Name;
                process.EmployeeName = "Şube Müdür Yardımcısı - Muammer Akal";
                process.Description = "Para Çekme İşlemi Günlük Limiti Aştı, İşlem Şube Müdürüne Yönlendirildi.";
                c.customerProcesses.Add(process);
                c.SaveChanges();
                NextApprover.ProcessRequest(req);
            }
        }
    }
}
