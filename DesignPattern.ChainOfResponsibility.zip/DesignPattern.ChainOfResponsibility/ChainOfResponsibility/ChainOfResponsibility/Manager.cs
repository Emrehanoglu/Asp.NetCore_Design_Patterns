﻿using ChainOfResponsibility.DAL;
using ChainOfResponsibility.Models;

namespace ChainOfResponsibility.ChainOfResponsibility
{
    public class Manager : Employee
    {
        public override void ProcessRequest(CustomerProcessViewModel req)
        {
            Context c = new Context();
            CustomerProcess process = new CustomerProcess();
            if (req.Amount < 250000)
            {
                process.Amount = req.Amount.ToString();
                process.Name = req.Name;
                process.EmployeeName = "Şube Müdürü - Enes Bucak";
                process.Description = "Para Çekme İşlemi Onaylandı, Müşteriye Talep Ettiği Tutar Ödendi.(Maks Tutar - 250000)";
                c.customerProcesses.Add(process);
                c.SaveChanges();
            }
            else if (NextApprover != null)
            {
                process.Amount = req.Amount.ToString();
                process.Name = req.Name;
                process.EmployeeName = "Şube Müdürü - Enes Bucak";
                process.Description = "Para Çekme İşlemi Günlük Limiti Aştı, İşlem Bölge Müdürüne Yönlendirildi.";
                c.customerProcesses.Add(process);
                c.SaveChanges();
                NextApprover.ProcessRequest(req);
            }
        }
    }
}
