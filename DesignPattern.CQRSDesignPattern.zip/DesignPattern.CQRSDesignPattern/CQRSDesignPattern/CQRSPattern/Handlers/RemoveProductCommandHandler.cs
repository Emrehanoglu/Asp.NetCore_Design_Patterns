﻿using CQRSDesignPattern.CQRSPattern.Commands;
using CQRSDesignPattern.DAL;

namespace CQRSDesignPattern.CQRSPattern.Handlers
{
    public class RemoveProductCommandHandler
    {
        private readonly Context _context;

        public RemoveProductCommandHandler(Context context)
        {
            _context = context;
        }
        public void Handle(RemoveProductCommand command)
        {
            var value = _context.Set<Product>().Find(command.Id);
            _context.Remove(value);
        }
    }
}
