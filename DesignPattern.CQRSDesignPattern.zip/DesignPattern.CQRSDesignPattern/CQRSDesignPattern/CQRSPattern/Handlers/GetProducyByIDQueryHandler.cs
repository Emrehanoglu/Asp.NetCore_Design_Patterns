﻿using CQRSDesignPattern.CQRSPattern.Queries;
using CQRSDesignPattern.CQRSPattern.Results;
using CQRSDesignPattern.DAL;
using Microsoft.AspNetCore.Mvc.ViewFeatures.Buffers;

namespace CQRSDesignPattern.CQRSPattern.Handlers
{
    public class GetProducyByIDQueryHandler
    {
        private readonly Context _context;

        public GetProducyByIDQueryHandler(Context context)
        {
            _context = context;
        }
        public GetProductByIdQueryResult Handle(GetProductByIdQuery query)
        {
            var values = _context.Set<Product>().Find(query.ID);
            return new GetProductByIdQueryResult
            {
                ProductID = values.ProductID,
                Name = values.Name,
                Price = values.Price,
                Stock = values.Stock
            };
        }
    }
}
