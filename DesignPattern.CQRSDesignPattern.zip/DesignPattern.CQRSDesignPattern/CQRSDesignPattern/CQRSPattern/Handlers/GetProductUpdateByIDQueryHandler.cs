﻿using CQRSDesignPattern.CQRSPattern.Queries;
using CQRSDesignPattern.CQRSPattern.Results;
using CQRSDesignPattern.DAL;

namespace CQRSDesignPattern.CQRSPattern.Handlers
{
    public class GetProductUpdateByIDQueryHandler
    {
        private readonly Context _context;

        public GetProductUpdateByIDQueryHandler(Context context)
        {
            _context = context;
        }
        public GetProductUpdateByIdQueryResult Handle(GetProductUpdateByIdQuery query)
        {
            var value = _context.Products.Find(query.ID);
            return new GetProductUpdateByIdQueryResult
            {
                ProductID = value.ProductID,
                Name = value.Name,
                Price = value.Price,
                Stock = value.Stock,
                Description = value.Description
            };
        }
    }
}
