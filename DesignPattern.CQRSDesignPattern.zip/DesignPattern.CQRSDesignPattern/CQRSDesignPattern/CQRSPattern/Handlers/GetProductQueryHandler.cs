﻿using CQRSDesignPattern.CQRSPattern.Results;
using CQRSDesignPattern.DAL;
using System.Collections.Generic;
using System.Linq;

namespace CQRSDesignPattern.CQRSPattern.Handlers
{
    public class GetProductQueryHandler
    {
        private readonly Context _context;

        public GetProductQueryHandler(Context context)
        {
            _context = context;
        }
        public List<GetProductQueryResult> Handle()
        {
            var degerler = _context.Products.Select(x => new GetProductQueryResult
            {
                ID = x.ProductID,
                Price = x.Price,
                Stock = x.Stock,
                ProductName = x.Name
            }).ToList();
            return degerler;
        }
    }
}
