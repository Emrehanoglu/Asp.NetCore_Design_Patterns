﻿using CQRSDesignPattern.CQRSPattern.Commands;
using CQRSDesignPattern.DAL;

namespace CQRSDesignPattern.CQRSPattern.Handlers
{
    public class CreateProductCommandHandler
    {  
        private readonly Context _context;

        public CreateProductCommandHandler(Context context)
        {
            _context = context;
        }
        public void Handle(CreateProductCommand createProductCommand)
        {
            _context.Products.Add(new Product
            {
                Name = createProductCommand.Name,
                Price = createProductCommand.Price,
                Stock = createProductCommand.Stock,
                Description = createProductCommand.Description,
                Status = true
            });
            _context.SaveChanges();
        }
    }
}
