﻿namespace CQRSDesignPattern.CQRSPattern.Queries
{
    public class GetProductByIdQuery
    {
        public GetProductByIdQuery(int id) 
        {
            ID = id;
        }
        public int ID { get; set; }
    }
}
