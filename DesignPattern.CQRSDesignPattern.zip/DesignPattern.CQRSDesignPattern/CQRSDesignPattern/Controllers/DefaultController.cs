﻿using CQRSDesignPattern.CQRSPattern.Commands;
using CQRSDesignPattern.CQRSPattern.Handlers;
using CQRSDesignPattern.CQRSPattern.Queries;
using CQRSDesignPattern.CQRSPattern.Results;
using Microsoft.AspNetCore.Mvc;

namespace CQRSDesignPattern.Controllers
{
    public class DefaultController : Controller
    {
        private readonly GetProductQueryHandler _getProductQueryHandler;
        private readonly CreateProductCommandHandler _createProductCommandHandler;
        private readonly GetProducyByIDQueryHandler _getProductByIdQueryHandler;
        private readonly RemoveProductCommandHandler _removeProductCommandHandler;
        private readonly GetProductUpdateByIDQueryHandler _getProductUpdateByIDQueryHandler;
        private readonly UpdateProductCommandHandler _updateProductCommandHandler;

        public DefaultController(GetProductQueryHandler getProductQueryHandler, 
                                 CreateProductCommandHandler createProductCommandHandler,
                                 GetProducyByIDQueryHandler getProductByIdQueryHandler,
                                 RemoveProductCommandHandler removeProductCommandHandler,
                                 GetProductUpdateByIDQueryHandler getProductUpdateByIDQueryHandler,
                                 UpdateProductCommandHandler updateProductCommandHandler)
        {
            _createProductCommandHandler = createProductCommandHandler;
            _getProductQueryHandler = getProductQueryHandler;
            _getProductByIdQueryHandler = getProductByIdQueryHandler;
            _removeProductCommandHandler = removeProductCommandHandler;
            _getProductUpdateByIDQueryHandler = getProductUpdateByIDQueryHandler;
            _updateProductCommandHandler = updateProductCommandHandler;
        }

        public IActionResult Index()
        {
            var values = _getProductQueryHandler.Handle();
            return View(values);
        }
        [HttpGet]
        public IActionResult AddProduct()
        {
            return View();
        }
        [HttpPost]
        public IActionResult AddProduct(CreateProductCommand product)
        {
            _createProductCommandHandler.Handle(product);
            return RedirectToAction("Index");
        }
        public IActionResult GetProduct(int id)
        {
            var value = _getProductByIdQueryHandler.Handle(new GetProductByIdQuery(id));
            return View(value);
        }
        public IActionResult RemoveProduct(int id)
        {
            _removeProductCommandHandler.Handle(new RemoveProductCommand(id));
            return RedirectToAction("Index");
        }
        [HttpGet]
        public IActionResult UpdateProduct(int id)
        {
            var value = _getProductUpdateByIDQueryHandler.Handle(new GetProductUpdateByIdQuery(id));
            return View(value);
        }
        [HttpPost]
        public IActionResult UpdateProduct(UpdateProductCommand command)
        {
            _updateProductCommandHandler.Handle(command);
            return RedirectToAction("Index");
        }
    }
}
