﻿using BusinessLayer.Abstract;
using Entity.Concrete;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Collections.Generic;
using System.Linq;

namespace Repository.Controllers
{
    public class ProductController : Controller
    {
        private readonly IProductService _ProductService;
        private readonly ICategoryService _CategoryService;
        public ProductController(IProductService ProductService, ICategoryService categoryService)
        {
            _ProductService = ProductService;
            _CategoryService = categoryService;
        }
        public IActionResult Index()
        {
            //var values = _ProductService.TGetAll();
            var values = _ProductService.TProductListWithCategory();
            return View(values);
        }
        [HttpGet]
        public IActionResult AddProduct()
        {
            List<SelectListItem> values = (from x in _CategoryService.TGetAll()
                                           select new SelectListItem
                                           {
                                               Text = x.CategoryName,
                                               Value = x.CategoryId.ToString()
                                           }).ToList();
            ViewBag.kategoriler = values;
            return View();
        }
        [HttpPost]
        public IActionResult AddProduct(Product Product)
        {
            _ProductService.TInsert(Product);
            return RedirectToAction("Index");
        }
        public IActionResult DeleteProduct(int id)
        {
            var value = _ProductService.TGetById(id);
            _ProductService.TDelete(value);
            return RedirectToAction("Index");
        }
        [HttpGet]
        public IActionResult UpdateProduct(int id)
        {
            List<SelectListItem> values2 = (from x in _CategoryService.TGetAll()
                                           select new SelectListItem
                                           {
                                               Text = x.CategoryName,
                                               Value = x.CategoryId.ToString()
                                           }).ToList();
            ViewBag.kategoriler = values2;
            var values = _ProductService.TGetById(id);
            return View(values);
        }
        [HttpPost]
        public IActionResult UpdateProduct(Product Product)
        {
            _ProductService.TUpdate(Product);
            return RedirectToAction("Index");
        }
    }
}
