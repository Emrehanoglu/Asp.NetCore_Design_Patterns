﻿using Iterator.IteratorPattern;
using Microsoft.AspNetCore.Mvc;

namespace Iterator.Controllers
{
    public class DefaultController : Controller
    {
        public IActionResult Index()
        {
            VisitRouteMover visitRouteMover = new VisitRouteMover();
            List<string> routes = new List<string>();

            visitRouteMover.Add(new VisitRoute { CountryName = "Almanya", CityName = "Berlin", VisitPlaceName = "Berlin Kapısı" });
            visitRouteMover.Add(new VisitRoute { CountryName = "Fransa", CityName = "Paris", VisitPlaceName = "Eyfel" });
            visitRouteMover.Add(new VisitRoute { CountryName = "İtalya", CityName = "Venedik", VisitPlaceName = "Gondol" });
            visitRouteMover.Add(new VisitRoute { CountryName = "İtalya", CityName = "Roma", VisitPlaceName = "Kolezyum" });
            visitRouteMover.Add(new VisitRoute { CountryName = "Çek Cumhuriyeti", CityName = "Prag", VisitPlaceName = "Meydan" });

            var iterator = visitRouteMover.CreatorIterator();

            while (iterator.NextLocation())
            {
                routes.Add(iterator.CurrentItem.CountryName + " " + iterator.CurrentItem.CityName + " " + iterator.CurrentItem.VisitPlaceName);
            }

            ViewBag.v = routes;

            return View();
        }
    }
}
