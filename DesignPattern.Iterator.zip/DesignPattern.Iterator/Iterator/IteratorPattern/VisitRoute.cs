﻿namespace Iterator.IteratorPattern
{
    public class VisitRoute
    {
        public string CountryName { get; set; }
        public string CityName { get; set; }
        public string VisitPlaceName { get; set; }
    }
}
