﻿using Microsoft.EntityFrameworkCore;

namespace Mediator.DAL
{
    public class Context : DbContext
    {
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("server=(localdb)\\MSSQLLocalDB;database=DesignPattern4;integrated security = true");
        }

        public DbSet<Product> Products { get; set; }
    }
}
