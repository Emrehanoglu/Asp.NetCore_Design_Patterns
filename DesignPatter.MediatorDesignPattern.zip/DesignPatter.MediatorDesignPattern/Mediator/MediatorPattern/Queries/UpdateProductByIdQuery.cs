﻿using Mediator.MediatorPattern.Results;
using MediatR;

namespace Mediator.MediatorPattern.Queries
{
    public class UpdateProductByIdQuery : IRequest<UpdateProductByIdResults>
    {
        public UpdateProductByIdQuery(int id)
        {
            Id = id;
        }

        public int Id { get; set; }
    }
}
