﻿using Mediator.DAL;
using Mediator.MediatorPattern.Commands;
using MediatR;

namespace Mediator.MediatorPattern.Handlers
{
    public class RemoveProductCommandHandler : IRequestHandler<RemoveProductCommand>
    {
        private readonly Context _context;

        public RemoveProductCommandHandler(Context context)
        {
            _context = context;
        }

        public async Task Handle(RemoveProductCommand request, CancellationToken cancellationToken)
        {
            var value = await _context.Products.FindAsync(request.Id);
            _context.Products.Remove(value);
            _context.SaveChanges();
        }
    }
}
