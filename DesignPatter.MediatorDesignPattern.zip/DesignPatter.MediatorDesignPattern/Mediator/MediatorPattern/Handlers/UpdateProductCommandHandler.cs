﻿using Mediator.DAL;
using Mediator.MediatorPattern.Commands;
using MediatR;

namespace Mediator.MediatorPattern.Handlers
{
    public class UpdateProductCommandHandler : IRequestHandler<UpdateProductCommand>
    {
        private readonly Context _context;

        public UpdateProductCommandHandler(Context context)
        {
            _context = context;
        }

        public async Task Handle(UpdateProductCommand request, CancellationToken cancellationToken)
        {
            var value = _context.Products.Find(request.ProductId);
            value.ProductName = request.ProductName;
            value.ProductStock = request.ProductStock;
            value.ProductPrice = request.ProductPrice;
            value.ProductCategory = request.ProductCategory;
            value.ProductStockType = request.ProductStockType;
            await _context.SaveChangesAsync();
        }
    }
}
