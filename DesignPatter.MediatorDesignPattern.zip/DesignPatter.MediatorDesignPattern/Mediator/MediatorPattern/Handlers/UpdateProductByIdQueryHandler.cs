﻿using Mediator.DAL;
using Mediator.MediatorPattern.Queries;
using Mediator.MediatorPattern.Results;
using MediatR;

namespace Mediator.MediatorPattern.Handlers
{
    public class UpdateProductByIdQueryHandler : IRequestHandler<UpdateProductByIdQuery, UpdateProductByIdResults>
    {
        private readonly Context _context;
        public UpdateProductByIdQueryHandler(Context context)
        {
            _context = context;
        }

        public async Task<UpdateProductByIdResults> Handle(UpdateProductByIdQuery request, CancellationToken cancellationToken)
        {
            var value = await _context.Products.FindAsync(request.Id);
            return new UpdateProductByIdResults
            {
                ProductId = value.ProductId,
                ProductName = value.ProductName,
                ProductCategory = value.ProductCategory,
                ProductPrice = value.ProductPrice,
                ProductStock = value.ProductStock,
                ProductStockType = value.ProductStockType
            };
        }
    }
}
