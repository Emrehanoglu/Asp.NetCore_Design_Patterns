﻿using Mediator.DAL;
using Mediator.MediatorPattern.Commands;
using MediatR;

namespace Mediator.MediatorPattern.Handlers
{
    public class AddProductCommandHandler : IRequestHandler<AddProductCommand>
    {
        private readonly Context _context;
        public AddProductCommandHandler(Context context)
        {
            _context = context;
        }

        public async Task Handle(AddProductCommand request, CancellationToken cancellationToken)
        {
            _context.Add(new Product
            {
                ProductName = request.ProductName,
                ProductCategory = request.ProductCategory,
                ProductPrice = request.ProductPrice,
                ProductStock = request.ProductStock,
                ProductStockType = request.ProductStockType
            });
            await _context.SaveChangesAsync();
        }
    }
}
