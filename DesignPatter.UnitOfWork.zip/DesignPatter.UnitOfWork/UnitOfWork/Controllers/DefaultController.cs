﻿using BusinessLayer.Abstract;
using EntityLayer.Concrete;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Collections.Generic;
using System.Linq;
using UnitOfWork.Models;

namespace UnitOfWork.Controllers
{
    public class DefaultController : Controller
    {
        private readonly ICustomerService _customerService;
        public DefaultController(ICustomerService customerService)
        {
            _customerService = customerService;
        }
        [HttpGet]
        public IActionResult Index()
        {
            List<SelectListItem> sender = (from x in _customerService.TGetAll()
                                           select new SelectListItem
                                           {
                                               Text = x.CustomerName,
                                               Value = x.CustomerId.ToString()
                                           }).ToList();
            List<SelectListItem> receiver = (from x in _customerService.TGetAll()
                                           select new SelectListItem
                                           {
                                               Text = x.CustomerName,
                                               Value = x.CustomerId.ToString()
                                           }).ToList();
            ViewBag.sender = sender;
            ViewBag.receiver = receiver;
            return View();
        }
        [HttpPost]
        public IActionResult Index(CustomerViewModel model)
        {
            var value1 = _customerService.TGetById(model.SenderId);
            var value2 = _customerService.TGetById(model.ReceiverId);

            value1.CustomerBalance -= model.Amount;
            value2.CustomerBalance += model.Amount;

            List<Customer> modeifiedCustomers = new List<Customer>()
            {
                value1,
                value2
            };

            _customerService.TMultiUpdate(modeifiedCustomers);

            return RedirectToAction("Index");
        }
    }
}
