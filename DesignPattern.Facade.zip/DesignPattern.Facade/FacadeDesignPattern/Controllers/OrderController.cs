﻿using FacadeDesignPattern.DAL;
using FacadeDesignPattern.Facade;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Linq;

namespace FacadeDesignPattern.Controllers
{
    public class OrderController : Controller
    {
        Context context = new Context();
        OrderFacade orderFacade = new OrderFacade();   
        public IActionResult Index()
        {
            return View();
        }
        [HttpGet]
        public IActionResult OrderDetailStart()
        {
            return View();
        }
        [HttpPost]
        public IActionResult OrderDetailStart(int customerId, int productId, int orderId, int productCount, decimal productPrice)
        {
            orderFacade.CompleteOrderDetail(customerId, productId, orderId, productCount, productPrice);
            return RedirectToAction("Index");
        }
        [HttpGet]
        public IActionResult OrderStart()
        {
            List<SelectListItem> müsteriler = (from i in context.Customers.ToList()
                                           select new SelectListItem
                                           {
                                               Text = i.CustomerName + " " + i.CustomerSurname,
                                               Value = i.CustomerID.ToString()
                                           }).ToList();
            ViewBag.must = müsteriler;
            return View();
        }
        [HttpPost]
        public IActionResult OrderStart(int customerId)
        {
            orderFacade.CompleteOrder(customerId);
            return View("OrderDetailStart");
        }
    }
}
