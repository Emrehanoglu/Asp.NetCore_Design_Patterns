﻿namespace FacadeDesignPattern.Facade
{
    public class ProductFacade
    {
    }
}
