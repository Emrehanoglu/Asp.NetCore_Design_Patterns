﻿using FacadeDesignPattern.DAL;

namespace FacadeDesignPattern.Facade
{
    public class OrderFacade
    {
        Order order = new Order();
        OrderDetail orderDetail = new OrderDetail();
        ProductStock productStock = new ProductStock();
        AddOrder addOrder = new AddOrder();
        AddOrderDetail addOrderDetail = new AddOrderDetail();

        public void CompleteOrderDetail(int customerId, int productId, int orderId, int productCount, decimal productPrice)
        {
            orderDetail.CustomerId = customerId;
            orderDetail.ProductId = productId;
            orderDetail.OrderId = orderId;
            orderDetail.ProductPrice = productPrice;
            orderDetail.ProductCount = productCount;
            decimal totalPrice = productCount * productPrice;
            orderDetail.TotalPrice = totalPrice;
            addOrderDetail.AddNewOrderDetail(orderDetail);

            productStock.DecraseProduct(productId,productCount);
        }
        public void CompleteOrder(int customerId)
        {
            order.CustomerId = customerId;
            addOrder.AddNewOrder(order);
        }
    }
}
