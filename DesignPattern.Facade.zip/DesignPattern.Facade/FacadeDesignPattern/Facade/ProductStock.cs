﻿using FacadeDesignPattern.DAL;

namespace FacadeDesignPattern.Facade
{
    public class ProductStock
    {
        Context context = new Context();
        public void DecraseProduct(int id,int amount)
        {
            var value = context.Products.Find(id);
            value.ProductStock -= amount;
            context.SaveChanges();
        }
    }
}
