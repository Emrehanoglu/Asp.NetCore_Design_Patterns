﻿using Microsoft.AspNetCore.Mvc;
using TemplateMethodDesignPattern.Template;

namespace TemplateMethodDesignPattern.Controllers
{
    public class DefaultController : Controller
    {
        public IActionResult BasicPlanIndex() 
        {
            NetflixPlans basic = new BasicPlan();
            ViewBag.v1 = basic.PlanType("Temel Plan");
            ViewBag.v2 = basic.CountPerson(1);
            ViewBag.v3 = basic.Price(64.99);
            ViewBag.v4 = basic.Resolution("480px");
            ViewBag.v5 = basic.Content("Film-Dizi");
            return View();
        }
        public IActionResult StandardPlanIndex()
        {
            NetflixPlans basic = new StandartPlan();
            ViewBag.v1 = basic.PlanType("Standart Plan");
            ViewBag.v2 = basic.CountPerson(4);
            ViewBag.v3 = basic.Price(99.99);
            ViewBag.v4 = basic.Resolution("720px");
            ViewBag.v5 = basic.Content("Film-Dizi-Animasyon");
            return View();
        }
        public IActionResult ExtendedPlanIndex()
        {
            NetflixPlans basic = new ExtendedPlan();
            ViewBag.v1 = basic.PlanType("Genişletilmiş Plan");
            ViewBag.v2 = basic.CountPerson(6);
            ViewBag.v3 = basic.Price(134.99);
            ViewBag.v4 = basic.Resolution("1080px");
            ViewBag.v5 = basic.Content("Film-Dizi-Animasyon-Belgesel");
            return View();
        }
    }
}
