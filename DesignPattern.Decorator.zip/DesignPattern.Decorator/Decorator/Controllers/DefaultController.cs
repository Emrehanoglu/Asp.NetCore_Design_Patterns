﻿using Decorator.DAL;
using Decorator.DecoratorPattern2;
using Microsoft.AspNetCore.Mvc;

namespace Decorator.Controllers
{
    public class DefaultController : Controller
    {
        public IActionResult Index()
        {
            Message message = new Message();
            message.MessageContent = "Bu bir content mesajıdır";
            message.MessageSender = "Admin IK";
            message.MessageReceiver = "Herkes";
            message.MessageSubject = "Deneme yapıyoruz.";
            CreateNewSendMessage createNewSendMessage = new CreateNewSendMessage();
            createNewSendMessage.NewSendMessage(message);
            return View();
        }
        public IActionResult Index2()
        {
            Message message = new Message();
            message.MessageSender = "İnsan Kaynakları";
            message.MessageReceiver = "Yazılım Ekibi";
            message.MessageContent = "Saat 12.00 ' de toplantı var";
            message.MessageSubject = "Toplantı";
            CreateNewSendMessage createNewSendMessage = new CreateNewSendMessage();
            EncryptoBySubjectDecorator encryptoBySubjectDecorator = new EncryptoBySubjectDecorator(createNewSendMessage);
            encryptoBySubjectDecorator.SendMessageByEncryptoSubject(message);
            return View();
        }
    }
}
