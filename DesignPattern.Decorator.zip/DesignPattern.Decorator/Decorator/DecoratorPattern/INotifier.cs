﻿using Decorator.DAL;

namespace Decorator.DecoratorPattern
{
    public interface INotifier
    {
        public void CreateNotify(Notifier notifier);
    }
}
