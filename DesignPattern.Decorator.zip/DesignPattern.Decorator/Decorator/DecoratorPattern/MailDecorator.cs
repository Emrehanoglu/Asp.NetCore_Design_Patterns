﻿using Decorator.DAL;

namespace Decorator.DecoratorPattern
{
    public class MailDecorator : Decorator
    {
        Context context = new Context();
        private readonly INotifier _notifier;
        public MailDecorator(INotifier notifier) : base(notifier)
        {
            _notifier = notifier;
        }
        //2 türlü yapılabilir.
        //Birincisi kendimiz bir method yazarak bildirimciyi oluşturabiliriz.
        //İkincisi override ile decorator sınıfındaki CreateNotify methodunu kullanabiliriz.
        //Ama bu iki kullanımda çok doğru olmayacak. 
        //DecoratorPattern2 ye geçiyorum. Tıkandı burası.
        public void SendMailNotify(Notifier notifier)
        {
            notifier.NotifierCreator = "Scrum Master";
            notifier.NotifierSubject = "Günlük Sabah Toplantısı";
            notifier.NotifierChannel = "Gmail-Outlook";
            notifier.NotifierType = "Private Team";
            context.Notifiers.Add(notifier);
            context.SaveChanges();
        }
        public override void CreateNotify(Notifier notifier)
        {
            base.CreateNotify(notifier);
            SendMailNotify(notifier);
        }
    }
}
