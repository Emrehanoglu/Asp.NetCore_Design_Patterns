﻿using Decorator.DAL;

namespace Decorator.DecoratorPattern2
{
    public class Decorator : ISendMessage
    {
        private readonly ISendMessage _isendMessage;

        public Decorator(ISendMessage isendMessage)
        {
            _isendMessage = isendMessage;
        }

        virtual public void NewSendMessage(Message message)
        {
            message.MessageReceiver = "Herkes";
            message.MessageSender = "Admin";
            message.MessageContent = "Merhaba bu bir toplantı hatırlatmasıdır.";
            message.MessageSubject = "Toplantı";
            _isendMessage.NewSendMessage(message);
        }
    }
}
