﻿using Decorator.DAL;
using System;

namespace Decorator.DecoratorPattern2
{
    public class EncryptoByContentDecorator : Decorator
    {
        private readonly ISendMessage _isendMessage;
        Context context = new Context();
        public EncryptoByContentDecorator(ISendMessage isendMessage) : base(isendMessage)
        {
            _isendMessage = isendMessage;
        }
        public void SendMessageByEncryptoContent(Message message)
        {
            message.MessageSender = "Takım Lideri";
            message.MessageReceiver = "Yazılım Ekibi";
            message.MessageContent = "Saat 17.00 ' de aktarım olacak.";
            message.MessageSubject = "Toplantı";
            string data = message.MessageContent;
            char[] chars = data.ToCharArray();
            foreach(var x in chars)
            {
                message.MessageContent = Convert.ToChar(x + 3).ToString();
            }
            context.Messages.Add(message);
            context.SaveChanges();
        }
        public override void NewSendMessage(Message message)
        {
            base.NewSendMessage(message);
            SendMessageByEncryptoContent(message);
        }
    }
}
