﻿using Decorator.DAL;
using System;

namespace Decorator.DecoratorPattern2
{
    public class EncryptoBySubjectDecorator : Decorator
    {
        Context context = new Context();
        private readonly ISendMessage _isendMessage;
        public EncryptoBySubjectDecorator(ISendMessage isendMessage) : base(isendMessage)
        {
            _isendMessage = isendMessage;
        }
        public void SendMessageByEncryptoSubject(Message message)
        {
            string data = message.MessageSubject;
            char[] chars = data.ToCharArray();
            foreach ( char c in chars ) 
            {
                message.MessageSubject += Convert.ToChar(c + 3).ToString();
            }
            context.Messages.Add(message);
            context.SaveChanges();  
        }
        public override void NewSendMessage(Message message)
        {
            base.NewSendMessage(message);
            SendMessageByEncryptoSubject(message);
        }
    }
}
