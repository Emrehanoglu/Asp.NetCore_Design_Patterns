﻿using Decorator.DAL;

namespace Decorator.DecoratorPattern2
{
    public interface ISendMessage
    {
        public void NewSendMessage(Message message);
    }
}
